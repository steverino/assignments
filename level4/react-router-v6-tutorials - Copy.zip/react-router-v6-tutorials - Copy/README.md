# React Router v6 Tutorial

## Command to clone repo
  ### Clone with SSH
    * git clone git@github.com:v-school/react-router-v6-tutorials.git
    * cd react-router-v6-tutorials
    * rm -rf .git
    * code .
    * run npm install to get dependencies