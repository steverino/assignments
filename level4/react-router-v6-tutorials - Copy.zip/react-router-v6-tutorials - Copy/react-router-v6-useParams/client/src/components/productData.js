const productData = [
    {
        "name": "fishing rod",
        "price": 30,
        "_id": "1",
        "description": "Use this to catch some fish."
    },
    {
        "name": "Rake",
        "price": 50,
        "_id": "2",
        "description": "Gather up the leaves in your yard into piles."
    },
    {
        "name": "Hat",
        "price": 50,
        "_id": "3",
        "description": "Wear this on your head"
    },
    {
        "name": "Shovel",
        "price": 100,
        "_id": "4",
        "description": "Use this to dig a hole in the ground."
    }
]

export default productData